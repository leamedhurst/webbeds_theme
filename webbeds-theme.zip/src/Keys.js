// Key map
export const ENTER = 13;
export const ESCAPE = 27;
export const SPACE = 32;
export const UP = 38;
export const DOWN = 40;
export const TAB = 9;
