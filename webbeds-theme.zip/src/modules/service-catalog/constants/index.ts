export const AttachmentsInputName = "attachments" as const;

export const ASSET_TYPE_KEY = "zen:custom_object:standard::itam_asset_type";
export const ASSET_KEY = "zen:custom_object:standard::itam_asset";
