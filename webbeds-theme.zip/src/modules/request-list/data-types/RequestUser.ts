export interface RequestUser {
  id: number;
  name: string;
  alias?: string;
}
