export interface User {
  id: number;
  name: string;
  organization_id: string;
  locale: string;
  role: string;
  authenticity_token: string;
}
