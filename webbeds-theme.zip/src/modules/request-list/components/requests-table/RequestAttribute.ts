export interface RequestAttribute {
  identifier: string;
  label: string;
}
