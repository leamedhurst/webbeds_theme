export default {
  assign(url: string): void {
    return window.location.assign(url);
  },
};
