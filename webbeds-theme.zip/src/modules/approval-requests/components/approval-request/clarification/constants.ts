export const MAX_COMMENTS = 40;
export const NEAR_COMMENTS_LIMIT_THRESHOLD = 5;
export const MAX_CHAR_COUNT = 500;
export const WARNING_THRESHOLD = 10;
export const DEFAULT_AVATAR_URL =
  "https://secure.gravatar.com/avatar/6d713fed56e4dd3e48f6b824b8789d7f?default=https%3A%2F%2Fassets.zendesk.com%2Fhc%2Fassets%2Fdefault_avatar.png&r=g";
